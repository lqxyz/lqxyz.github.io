# KNN.py for data classification
# Qun Liu
# 2015-4-11

import numpy as np

def loadDataSet(filename):
    '''
    This function read data from the file. Because the file has fixed format,
    each line has four data and a type label, and they are separated by comma.
    '''
    wholeData = open(filename).read().split('\n')
    labels = [ line.split(',')[4] for line in wholeData if line != '']
    dataSet = np.array([[float(x) for x in line.split(',')[0:4]] for line in wholeData if line != ''])
    return dataSet, labels

def knnClassify(newdata, k):
    # read train data
    dataSet, labels = loadDataSet('train_iris.data')
    nrows = dataSet.shape[0]
    sortedIndex= np.argsort(np.sqrt(np.sum((np.tile(newdata, (nrows, 1))-dataSet)**2, axis = 1))) # sum in row

    # Error check 
    if k > nrows or k <= 0:
        print "k should be no larger than " + str(nrows) + "."
    assert k <= nrows and k >= 1

    classCount = {}
    for i in range(k):
        voteLabel = labels[sortedIndex[i]]
        classCount[voteLabel] = classCount.get(voteLabel, 0) + 1

    maxCount = 0
    for key, value in classCount.items():
        if value > maxCount:
            maxCount = value
            maxIndex = key
    return maxIndex

def KNN(test_file_name, k):
    testDataSet, testLabels = loadDataSet(test_file_name)
    totalRows = testDataSet.shape[0]
    errorRows = sum([ float(knnClassify(testDataSet[i], k) != testLabels[i]) for i in range(totalRows) ])
    return errorRows / float(totalRows)

filename = 'test_iris.data'
for k in range(60):
    k = 2*k + 1
    print "Error rate is " + str(KNN(filename, k)*100) + "% in file " + filename + " when k is " + str(k) + "."
