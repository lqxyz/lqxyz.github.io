#!/usr/bin/env python
import numpy as np

train_image = np.fromfile('train-images.idx3-ubyte', dtype=np.uint8)
train_image = (train_image[16:]).reshape([60000,784])

train_label = np.fromfile('train-labels.idx1-ubyte', dtype=np.uint8)
train_label = (train_label[8:])

test_image = np.fromfile('t10k-images.idx3-ubyte', dtype=np.uint8)
test_image = (test_image[16:]).reshape([10000,784])

test_label = np.fromfile('t10k-labels.idx1-ubyte', dtype=np.uint8)
test_label = (test_label[8:])

def flagCalculation(train_image, train_label):
    '''
    flag is a dictionary, where the key is the label 0-9, and the values
    are the bool values indicate which column are all zeros
    '''
    flag = {}
    for i in range(10):
        flag[i] = np.array([ train_image[train_label == i, j].sum() != 0 for j in range(784) ])
    return flag

flag = flagCalculation(train_image, train_label)

# Calculate the A prioir probablity
p_y = np.array([train_label[train_label == i].shape[0]*1.0 / train_label.shape[0] for i in range(10)])

# Calculate the sigma and mu
sigma = {}
mu = {}
for i in range(10):
    mu[i]    = np.average(train_image[:, flag[i]][train_label == i, :], axis=0)
    sigma[i] = np.std(train_image[:, flag[i]][train_label == i, :], axis=0)

def calcP_xy(x_test):
    log_p_yx = {}
    for i in range(10):
        x_test_new = x_test[flag[i]]
        log_p_yx[i] = np.sum(np.log(1.0/sigma[i]/np.sqrt(2*np.pi)*np.exp(-(x_test_new-mu[i])**2/2.0/sigma[i]**2)+1e-100)) + np.log(p_y[i])
    return np.argmax(log_p_yx.values())

newLabel = np.zeros(10000)
for i in range(10000):
    newLabel[i] = calcP_xy(test_image[i,:])

error = sum(test_label != newLabel)*1.0/10000
print "Error rate is " + str(error*100) + "%."