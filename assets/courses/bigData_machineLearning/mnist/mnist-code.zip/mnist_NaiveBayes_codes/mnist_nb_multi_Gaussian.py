#!/usr/bin/env python
import numpy as np

train_image = np.fromfile('train-images.idx3-ubyte', dtype=np.uint8)
train_image = (train_image[16:]).reshape([60000,784])
train_label = np.fromfile('train-labels.idx1-ubyte', dtype=np.uint8)
train_label = (train_label[8:])

test_image = np.fromfile('t10k-images.idx3-ubyte', dtype=np.uint8)
test_image = (test_image[16:]).reshape([10000,784])
test_label = np.fromfile('t10k-labels.idx1-ubyte', dtype=np.uint8)
test_label = (test_label[8:])

# Calculate the A prioir probablity
p_y = np.array([train_label[train_label == i].shape[0]*1.0 / train_label.shape[0] for i in range(10)])

# Calculate the sigma and mu
sigma = {}
mu = {}
invsigma ={}
Lambda = 15000
for i in range(10):
    dat = train_image[train_label == i, :]
    mu[i]    = np.average(dat, axis=0)
    sigma[i] = np.cov(dat, rowvar=0) + Lambda*np.eye(784, dtype=np.uint8)
    invsigma[i] = np.linalg.inv(sigma[i])

idx = np.zeros(10000, dtype=np.uint8)
for k in range(10000):
    kdat = test_image[k,:]
    gx = np.zeros(10)
    for j in range(10):
        gx[j] = -0.5*(kdat - mu[j]).dot(invsigma[j]).dot((kdat - mu[j]).T) + np.log(p_y[j])
    idx[k] = np.argmax(gx)

err = 1 - sum(idx == test_label)*1.0/10000
print "Error rate is " + str(err*100) + "%."