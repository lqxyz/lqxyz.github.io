#!/usr/bin/env python
import numpy as np
from sklearn.naive_bayes import MultinomialNB

#train examples: 60000, size: 28*28
train_image = np.fromfile('train-images.idx3-ubyte', dtype=np.uint8)
train_image = (train_image[16:]).reshape([60000,784])#/255.0

train_label = np.fromfile('train-labels.idx1-ubyte', dtype=np.uint8)
train_label = (train_label[8:])

#test examples: 10000, size: 28*28
test_image = np.fromfile('t10k-images.idx3-ubyte', dtype=np.uint8)
test_image = (test_image[16:]).reshape([10000,784])#/255.0

test_label = np.fromfile('t10k-labels.idx1-ubyte', dtype=np.uint8)
test_label = (test_label[8:])

# create a Navie Bayes model
model = MultinomialNB(alpha=0.001)
#print model

# train
model.fit(train_image, train_label)
print model

# test
newlabel = model.predict(test_image)
#print svm_class
error = sum(test_label != newlabel)*1.0/10000
print "Error rate is " + str(error*100) + "%."