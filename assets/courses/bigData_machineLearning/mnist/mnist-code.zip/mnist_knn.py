import numpy as np
from sklearn import neighbors

##### step 1: prepare the train set and test set from mnist database
#train examples: 60000, size: 28*28
train_image = np.fromfile('train-images.idx3-ubyte', dtype=np.uint8)
train_image = (train_image[16:]).reshape([60000,28*28])

train_label = np.fromfile('train-labels.idx1-ubyte', dtype=np.uint8)
train_label = (train_label[8:])

#test examples: 10000, size: 28*28
test_image = np.fromfile('t10k-images.idx3-ubyte', dtype=np.uint8)
test_image = (test_image[16:]).reshape([10000,28*28])

test_label = np.fromfile('t10k-labels.idx1-ubyte', dtype=np.uint8)
test_label = (test_label[8:])

##### step 2: get the classifier of knn

model = neighbors.KNeighborsClassifier(n_neighbors=3,weights='distance',algorithm='auto',leaf_size=30,p=2,metric='euclidean')

##### step 3: train with the traindata and trainlabels

model.fit(train_image,train_label)


##### step 4: make predictions

knn_class = model.predict(test_image)
knnerror = np.sum(knn_class != test_label)*1.0/knn_class.shape[0]

##### print result
print 'The knn classification is',knn_class
print 'The Error rate of knn is',knnerror


