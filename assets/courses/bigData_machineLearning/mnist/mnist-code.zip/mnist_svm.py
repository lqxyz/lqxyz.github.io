# mnist_svm by using scikit-learn 
import numpy as np
from sklearn import svm

# train examples: 60000, size: 28*28
train_image = np.fromfile('train-images.idx3-ubyte', dtype=np.uint8)
train_image = (train_image[16:]).reshape([60000,28*28])  

train_label = np.fromfile('train-labels.idx1-ubyte', dtype=np.uint8)
train_label = (train_label[8:])

# test examples: 10000, size: 28*28
test_image = np.fromfile('t10k-images.idx3-ubyte', dtype=np.uint8)
test_image = (test_image[16:]).reshape([10000,28*28])

test_label = np.fromfile('t10k-labels.idx1-ubyte', dtype=np.uint8)
test_label = (test_label[8:])

# select smaller train sample: 6000, size: 28*28 
strain_image = train_image[0:6000,:]
strain_label = train_label[0:6000]
# select smaller test sample: 1000= former500 + later500, size: 28*28 
stest_image = test_image[4500:5500,:]
stest_label = test_label[4500:5500]

# -- choose differnt functions to fit model -- # -- change kernel-- change parameters----#
#model = svm.LinearSVC()                        # choose lineaar condition
#model = svm.NuSVC(kernel="poly",degree=2)      # choose Non-lineaar condition
#model = svm.SVC(kernel="linear")               # create a svm with linear kernel
#model = svm.SVC(kernel="rbf",gamma=2)          # create a svm with rbf kernel
model = svm.SVC(kernel="poly",coef0=0.0,degree=2,gamma=0.0) # create a svm with polynomial kernel
#model = svm.SVC(kernel="sigmoid",coef0=0.0,gamma=1)    # create a svm with sogmoid kernel

# show the kernel type
model.kernel

# train, fit the model 
model.fit(train_image, train_label)

# test
svm_class = model.predict(test_image)

# error amount
error_count = 0
for i in xrange(test_label.shape[0]):
    if svm_class[i] !=  test_label[i]:
        error_count += 1
       
# error rate
errorRate = float(error_count) / float(test_label.shape[0])

#### with the case -- model = svm.SVC(), model = svm.SVC(kernel="**")
# get support vectors
#model.support_vectors_
# get indices of support vectors
#model.support_ 
# get number of support vectors for each class
#model.n_support_


