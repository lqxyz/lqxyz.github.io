import numpy as np
import matplotlib.pyplot as plt

### Problem 1
print "Problem 1..."
gamma = 7e-3
T0 = 298
L = 2264e3
R = 287.04

z = R*T0**2/(L+R*T0)/gamma
#print R*T0**2 
#print (L+R*T0)*gamma
print z

gamma = 6.5e-3
T0 = 339
z = R*T0**2/(L+R*T0)/gamma
print z


print ""
print "Problem 2(a)..."
z = 4*np.log(5)
print z

sigma=5.6734e-8
T=339
F0=1370/4.0
x=2*sigma*T**4/F0-1
print x


print "Problem 2(c)..."
T=500
gv=8.87
print R*T/gv
print "Problem 2(d)..."
print R*T/gv*np.log(100) 

print ""
# Problem 4

T_diff = 20.0
alpha = 2.0e-4
gamma = 8.0e-4
S0 = 35.0
k = 5.0e9
Sv = 1.0e6
Cp = 3989.24495292815
rho = 1.035e3

plt.close('all')
fig, ax = plt.subplots(1, 1)
E = np.linspace(-Sv, Sv, 200)
delta = k**2 * alpha**2 * T_diff**2 - 4*k*gamma*E*S0
E_new = E[delta>=0]
delta = delta[delta>=0]
q1 = 0.5*( k*alpha*T_diff + np.sqrt(delta) )
ax.plot(E_new/Sv,q1/Sv)
xticks = np.linspace(-1,1,9)
ax.set_xticks(xticks)
ax.set_xlim(-1,1)
ax.set_ylim(0,30)
ax.set_xlabel('E [Sv]')
ax.set_ylabel('q [Sv]')

plt.tight_layout()
fig.savefig('q1.pdf', bbox_inches='tight', pad_inches=0.1)

# Heat transport
fig, ax = plt.subplots(1, 1)

H1 = Cp*q1*T_diff*rho
E1 = E*L*rho
ax.plot(E_new/Sv,H1/1e15, label='by $q_1$')
ax.plot(E/Sv,E1/1e15, label='by $E$')
xticks = np.linspace(-1,1,9)
ax.set_xticks(xticks)
ax.set_xlim(-1,1)
#yticks = np.linspace(0,2,5)
#ax.set_yticks(yticks)
#ax.set_ylim(0,2.2)
ax.set_xlabel('E [Sv]')
ax.set_ylabel('Energy transport [$10^{15}$W]')
legend = ax.legend(loc='best', shadow=False, fontsize='large', frameon=False)
plt.tight_layout()
fig.savefig('H1.pdf', bbox_inches='tight', pad_inches=0.1)
