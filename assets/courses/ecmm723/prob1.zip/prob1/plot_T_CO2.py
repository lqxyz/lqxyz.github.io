import numpy as np
import matplotlib.pyplot as plt

Aw = 0.06
Ac = 0.6
S = 1370
S0 = 600
T0 = 273.15
p0 = 0.1e5
V0 = 0.1e5
W0 = 0.6e5
b = 10 
r = 1.0e1 # lambda

T_albedo_c = S/4.0*(1-Ac) - S0/4.0*(1-Aw)
T_albedo_w = S/4.0*(1-Aw) - S0/4.0*(1-Aw)
print T_albedo_c 
t1 = p0/V0*(np.exp(1.0/b*(-T_albedo_c) ) - 1.0) 
print 't1='+ str(t1)

plt.close('all')

fig, axes = plt.subplots(2,1, figsize=(8,10))

## CO2
t = np.linspace(0,t1,100)
co2 = V0*t+p0

axes[0].plot(t, co2/1000)

T = T0+1.0/r*(T_albedo_c + b*np.log(co2/p0) )
axes[1].plot(t, T)
axes[0].set_xlabel('t')
axes[0].set_ylabel('$p_{CO_2}$')
## Temperature
axes[1].set_xlabel('t')
axes[1].set_ylabel('Temperature')

t2 = t1+ (p0*(np.exp(1.0/b*(-T_albedo_w) )) - co2[-1])/(V0-W0)
print 't2='+str(t2)

t = np.linspace(t1,t2,1000)
co2 = co2[-1]+(V0-W0)*(t-t1)

axes[0].plot(t, co2/1000)

T = T0+1.0/r*(T_albedo_w + b*np.log(co2/p0) )
axes[1].plot(t, T)

plt.show()

t = np.linspace(0,t1*100,1000)
