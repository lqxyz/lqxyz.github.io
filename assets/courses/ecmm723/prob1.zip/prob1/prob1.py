import numpy as np

### Problem 1
print "Problem 1..."
gamma = 7e-3
T0 = 298
L = 2264e3
R = 287.04

z = R*T0**2/(L+R*T0)/gamma
#print R*T0**2 
#print (L+R*T0)*gamma
print z

gamma = 6.5e-3
T0 = 270
z = R*T0**2/(L+R*T0)/gamma
print z


print ""
print "Problem 2(a)..."
z = 4*np.log(5)
print z

print "Problem 2(c)..."
sigma=5.6734e-8
T=295
F0=1370/4.0
x=2*sigma*T**4/F0-1
print x
