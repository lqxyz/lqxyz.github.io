function f_int_cub = cubic_lagrange_interp(x_0, xl, xr, fll, fl, fr, frr)
% fl,fr function values left and right of x_0
% fll is left of fl
% frr is right of fr

beta = (x_0 - xl)/(xr - xl);

f_int_cub= -(1/6.0)*beta*(1-beta)*(2-beta)*fll ...  
      +(1/2.0)*(1+beta)*(1-beta)*(2-beta)*fl ...
      +(1/2.0)*(1+beta)*beta*(2-beta)*fr ...
      -(1/6.0)*(1+beta)*beta*(1-beta)*frr;
