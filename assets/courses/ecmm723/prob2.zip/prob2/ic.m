function val=ic(x);
%
% Initial condition for diffusion problem
if (0.25 <= x) & (x <= 0.75)
  val=1.0;
else
  val=0.0;
end;
