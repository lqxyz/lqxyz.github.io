function [u, v] = mixed_layer_velocity(ug, vg, h)
% Return the mixed layer wind velocity
% Input:
%   ug, vg is the geostrophic winds
%   h is the depth of mixed layer
% Output:
%   u, v is the wind in mixed layer

    Cd = 2.0e-3;    % Nondimensional drag coefficient
    f = 1.0e-4;     % Coriolis parameter

    kappa = Cd/f/h; % coefficient for mixed layer s/m
    u = ug;         % Initialize u, v to geostrophic values
    v = vg;
    Vb = abs(u + 1i*v);  % Initialize wind magnitude
    
    % Iterate to find boundary layer solution 
    % Stop if wind magnitude from this step is close enough to that from last step
    Vb_old = Vb; % Original wind magnitude
    err = 1.0;
    while err > 1e-6
        v = vg + kappa*Vb.*u;   
        u = ug - kappa*Vb.*v;
        Vb = abs(u+1i*v);    % new estimate for Vb
        % Max diffeerence between old and new estimate of wind magnitude,
        % use max(max()) if Vb is matrix
        err = max(max(abs(Vb-Vb_old))); 
        Vb_old = Vb;
    end