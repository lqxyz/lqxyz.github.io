function next_num = next(i, m_next, len)
% Input:
%   i is the current position
%   m_next is the next m th position
%   len is the number of list
% Output:
%   next_num is the index of the item m_next of i in the list

    next_num = mod(i + m_next - 1, len) + 1;

end