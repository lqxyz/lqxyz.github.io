function prev_num = prev(i, m_prev, len)
% Input:
%   i is the current position
%   m_prev is the previous m th position
%   len is the number of list
% Output:
%   prev_num is the index of the item m_prev of i in the list

    prev_num = mod(i-m_prev+len-1, len) + 1; 
    
end