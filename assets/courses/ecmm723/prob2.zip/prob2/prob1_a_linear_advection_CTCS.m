% Linear advection with CTCS scheme

clear; clc; close all

figure;

u = 2.0; % u velocity
t = 0.5; % time to run
nx = 51; % no. of grid points
dt = 0.005; % time step
dx = 1.0/(nx-1); % grid length
x = (0:1:nx-1).*dx;
c = (u*dt)/dx;

phi = zeros(nx,1);  % phi at time n
phip = zeros(nx,1); % phi at time n+1
phim = zeros(nx,1); % phi at time n-1

% Set initial condition
for j = 1:nx 
    phi(j) = ic(x(j));
end
% Plot the initial phi
h1 = plot(x, phi, '-');

%% Get the values at first time step with FTCS method
% Loop over grid points
for j = 1:nx 
    jm = prev(j, 1, nx);    % index of item previous to j
    jp = next(j, 1, nx);    % index of item next to j
    phip(j) = phi(j) - c/2.0*(phi(jp)- phi(jm));
end % j

phim = phi; % t = 0
phi = phip; % t = 1*dt

%% Loop over steps with CTCS scheme
nstep = t/dt;   % total number time step approximately
for istep = 2:nstep
  % Loop over grid points
  for j=1:nx 
    jm = prev(j, 1, nx); % index of item previous to j
    jp = next(j, 1, nx); % index of item next to j
    phip(j) = phim(j) - c*(phi(jp)- phi(jm)); % phi at time t = (n+1)*dt
  end % j
  phim = phi; % t = (n-1)*dt
  phi = phip; % t = n*dt
end % istep

%% Plot the phi at time t
hold on
h2 = plot(x, phi,'r');

% Add legends
legend([h1,h2], {'$$t=0$$','$$t=0.5$$'},'Interpreter','latex')
xlim([0,1])
set(gca, 'FontSize', 14)
% Add x and y label
xlabel('$$x$$', 'Interpreter','latex', 'FontSize', 18);
ylabel('$$\phi (x,t)$$', 'Interpreter','latex', 'FontSize', 18);

% Print the figure
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 6, 6*0.618]);
print(gcf,'linear_advection_CTCS.png','-dpng','-r300');