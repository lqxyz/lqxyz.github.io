% Linear advection with semi-Lagrange scheme

clear; clc; close all;

u = 2.0; % u velocity
t = 0.5; % total time to simulate
nx = 51; % no. of grid points
dt = 0.005; % time step
L = 1.0;
dx = L/(nx-1); % grid length
x = (0:L:nx-1).*dx;

phi = zeros(nx,1);  % phi at n time step
phip = zeros(nx,1); % phi at next step

% Set initial condition
for j = 1:nx 
    phi(j) = ic(x(j));
end
% Plot the initial phi
h1 =plot(x, phi, '-');

%% Loop over steps with semi-Lagrange method and cubic Lagrange interpolation
nstep = t/dt;
for istep = 1:nstep
  % Loop over grid points
  for j=1:nx
    % locate the new position of the fluid parcel
    x0 = mod(x(j)-u*dt, L);
    % find the parcel indexes that will be used in cubic Lagrange interpolation
    p = floor(u*dt/dx);
    jl = prev(j, p+1, nx);  % j-1
    jr = next(jl, 1, nx);   % j+1
    jll = prev(jl, 1, nx);  % j-2
    jrr = next(jl, 2, nx);  % j+2
    % Use cubic Lagrange interpolation to get the phi at next step   
    phip(j) = cubic_lagrange_interp( x0, x(jl), x(jr),...
        phi(jll), phi(jl), phi(jr), phi(jrr) );
  end % j
  phi = phip;   % new phi at istep
end % istep

%% Plot the phi at time t
hold on
h2 = plot(x, phi,'r');
% Add legend
legend([h1,h2], {'$$t=0$$','$$t=0.5$$'},'Interpreter','latex')
xlim([0,1])
set(gca, 'FontSize', 14)
% Add x and y labels
xlabel('$$x$$', 'Interpreter','latex', 'FontSize', 18);
ylabel('$$\phi (x,t)$$', 'Interpreter','latex', 'FontSize', 18);
% Print the figure
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 6, 6*0.618]);
print(gcf,'linear_advection_semi_Lagrange.png','-dpng','-r300');
