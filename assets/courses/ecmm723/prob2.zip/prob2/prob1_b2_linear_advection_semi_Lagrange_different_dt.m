% Plot linear advection with different time steps
clear; clc; close all;

figure;

u = 2.0; % u velocity
t = 0.5; % the total time to run
nx = 51; % no. of grid points
L = 1.0; % the length of x

dtlist = 0.005:0.005:0.025; % A list of time steps

% marks for plots with different time steps
marks = {'r-.','b--o','--','r--*','k:'};
h2 = {};
labels = {};

for i = 1:length(dtlist)
    dx = L/(nx-1); % grid length
    x = (0:L:nx-1).*dx;
    phi = zeros(nx,1); 
    phip = zeros(nx,1);

    % Set initial condition
    for j = 1:nx 
        phi(j) = ic(x(j));
    end
    % Plot inital state
    h1 = plot(x, phi, '-', 'LineWidth', 2);
    hold on
    
    % Loop over steps with semi-Lagrange method and cubic Lagrange interpolation
    dt = dtlist(i);
    nstep = t/dt;
    for istep = 1:nstep
      % Loop over grid points
      for j=1:nx
        % locate the new position of the fluid parcel
        x0 = mod(x(j)-u*dt, L);
        % find the parcel indexes that will be used in cubic Lagrange interpolation
        p = floor(u*dt/dx);
        jl = prev(j, p+1, nx);
        jr = next(jl, 1, nx);
        jll = prev(jl, 1, nx);
        jrr = next(jl, 2, nx);
        % Use cubic Lagrange interpolation to get the phi at next step 
        phip(j) = cubic_lagrange_interp( x0, x(jl), x(jr),...
            phi(jll), phi(jl), phi(jr), phi(jrr) );
      end % j
      phi = phip;
    end % istep
    % plot the phi for different time steps
    h2{i} = plot(x, phi, marks{i}, 'LineWidth', 1);
    labels{i} = ['$$\Delta t=', num2str(dt), '$$'];
end
% Add legends
legend([h1, h2{:}], {'$$t=0$$', labels{:}},'Interpreter','latex', 'Location','best')
xlim([0,1.1])
set(gca, 'FontSize', 14)
% Add x and y labels
xlabel('$$x$$', 'Interpreter','latex', 'FontSize', 18);
ylabel('$$\phi (x,t)$$', 'Interpreter','latex', 'FontSize', 18);

% Print the figure
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 9, 9*0.618]);
print(gcf,'linear_advection_semi_Lagrange_dt_inc.png','-dpng','-r300');