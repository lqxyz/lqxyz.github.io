% Wind turning in the mixed-layer

clc; clear; close all

ug = 10;        % Geostrophic u wind is fixed at 10m/s.
vg = 0;         % Geostrophic v wind is fixed at 0.
Cd = 2.0e-3;    % Nondimensional drag coefficient
f = 1.0e-4;     % Coriolis parameter

h = 300:3000;   % The depths of mixed layer
N = length(h);  

V = zeros(N,2); % Vectors for components u, v
Vb= zeros(N,1); % Magnitude of mixed layer wind
angles = zeros(N,1); % The anlges between geostrophic and mixed layer winds

for j = 1:N
    kappa = Cd/f/h(j);  % Coefficient for mixed layer s/m
    u = ug;             % Initialize u, v to geostrophic values
    v = vg;
    V(j,:) = [u v];     % Vector wind
    Vb(j) = abs(V(j,1) + 1i*V(j,2));  % Wind magnitude
    % Iterate to find boundary layer solution 
    % Stop if wind magnitude from this step is close enough to that from last step
    Vb_old = Vb(j);     % Original wind magnitude
    err = 1;
    while err > 1e-6
        v = vg + kappa*Vb(j)*u;      
        u = ug - kappa*Vb(j)*v;
        Vb(j) = abs(u + 1i*v) ;     % New estimate for Vb, use complex number
        V(j,:) = [u v];             % New estimate for V
        err = abs(Vb(j)-Vb_old);    % Diffeerence between old and new wind magnitude
        Vb_old = Vb(j);
    end 
    angles(j) = atand(v/u)-atand(vg/ug); % The angels between winds (in degree)
end

plot(h, angles, 'k') % Plot the angles against depths
xlabel('h (m)');
ylabel('Angle (degree)');
xlim([min(h), max(h)])
set(gca, 'FontSize', 14)

% Print the figures
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 6, 6*0.618]);
print(gcf, 'Angles_change_with_depth_of_mixed_layer.png', '-dpng', '-r300');