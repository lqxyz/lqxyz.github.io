% MATLAB file:   mixed_layer_wind_2.m    (2/13/02)
% Display of mixed layer solution for u and v
% given a specified horizontal geopotential field.
clc
clear all
close all
Lx = 12.e6;  Ly = 6.e6;      % horizontal domain size
cor = 1.e-4;                 % Coriolis parameter
Nx = 22; Ny =22 ;            % number of grid points in each direction
xx=linspace(-Lx/2,Lx/2,Nx);  % Nx gridpoints in x   
yy=linspace( 0,Ly,Ny);       % Ny gridpoints in y
[x,y]=meshgrid(xx,yy);       % Sets matrix for grid system in x and y
%  Define the function to be contoured
h = 1000;                    % boundary layer depth

k = pi/6.e6;                 % zonal wavenumber in units of 1/m
m=pi/6.e6;                   % meridional wavenumber
U0 = 5;                      % mean zonal velocity
A = -1.0e3;                  % constant value of streamfunction
%
phi =  9800 - (U0*cor)*y +A*cos(k*x).*sin(m*y);   
ug = U0-A/cor*m*cos(k*x).*cos(m*y);
vg = -A/cor*k*sin(k*x).*sin(m*y);

%% initialize wind magnitude to geostrophic
figure (1)
%subplot(2,1,1);
cs =contour(x/1000,y/1000,phi);     
axis([-6000 6000 0 6000])
clabel(cs), title('geopotential')
xlabel('x (km)'), ylabel('y (km)');

%%  velocity shown in arrows
figure(2)
subplot(121)
quiver(x/1000,y/1000,ug,vg,'r')
axis([-6000 6000 0  6000])
xlabel('x (km)'), ylabel('y (km)');
title('(a) geostrophic wind')
set(gca, 'fontsize', 14)

%% u v in mixed layer
subplot(122)
[ucomp, vcomp] = mixed_layer_velocity(ug, vg, h); % get wind speed in mixed layer
quiver(x/1000, y/1000, ucomp, vcomp) % vector plot for wind
axis([-6000 6000 0  6000])
xlabel('x (km)'), ylabel('y (km)');
set(gca, 'fontsize', 14)
title('(b) mixed layer wind')
% Print the figure
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 14, 9*0.618]);
print(gcf,'wind_compare.png','-dpng','-r300');

%% Vertical Velocity
figure,
dux = gradient(ucomp, mean(diff(xx))); % du/dx
[~, dvy] = gradient(vcomp, mean(diff(xx)), mean(diff(yy))); % dv/dy
w = -h.*(dux+dvy);
% plot the contourf of w
contourf(xx/1000, yy/1000, w);
h = colorbar;
ylabel(h, 'm/s')
% cs_w = contour(xx/1000, yy/1000, w);
% clabel(cs_w)
axis([-6000 6000 0  6000])
xlabel('x (km)')
ylabel('y (km)')
set(gca, 'fontsize', 14)
title('Vertical velocity')

% Print the figure
set(gcf, 'PaperUnits', 'Inches', 'PaperPosition', [0, 0, 9, 9*0.618]);
print(gcf,'vertical_velocity.png','-dpng','-r300');