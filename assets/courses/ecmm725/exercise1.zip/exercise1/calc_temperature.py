import numpy as np
# Problem 2
a=0.05
S=1370
sigma=5.6*10**(-8)

T_earth=((1-a)*S/4.0/sigma)**0.25
print T_earth

R_earth = 1
dst = [0.72,1.52,5.2]
for R in dst:
    T = (R_earth/R)**0.5*T_earth
    print T
print ""

# Problem 3
R = 287.04
g=9.8
p1=1000
p2=500
Tave=[273.15,293.15,1]
for Ta in Tave:
    dZ = R*Ta/g*np.log(p1/p2)
    print "Z2-Z1="+str(dZ)

print ""
# Problem 4
c_p = 1003.0
R = 287.04
print (850.0/100)**(R/c_p)*(273.15-50)
print (850.0/100)**(R/c_p)*(273.15-50)-273.15

rho_0 = 100*100/287.0/223.15
print 'rho_0='+str(rho_0)

c_v = 716.0
rho = (850.0/100)**(c_v/c_p)*rho_0
print 'rho='+str(rho)


# Problem 5
T = 273.15-60

N = g/(c_p*T)**0.5
period = 2*np.pi/N
print 'period='+str(period/60.0)+'min'
print period


# Problem 7
print 'CIN='+str(R*0.3/97.5*50)
print 'CAPE='+str(R*0.6/(68+95)*2*(95-68))
