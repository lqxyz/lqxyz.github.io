% Plot Temperature of a Day
clear;
clc;
close all;
% Define parameters
c = 4*10^6; %J.m^-2.K^-1
S = 1370;
a = 0.3;
phi = pi/6.0;
I0 = S*(1-a)*cos(phi);
tau = 86400; % seconds
d = 14*60*60;
I_ave = 2*d/pi/tau*I0;
sigma = 5.67*10^-8;
epsilon = 1.0;
T_ave = (I_ave/sigma/epsilon)^0.25;
B = 4*epsilon*sigma*T_ave^3;

% Coefficients
a0 = 6*d/pi/tau;
a1 = (pi*c/B/d)/(1+(pi*c/B/d)^2)* ((1+exp(B*d/c))/(1-exp(-B*tau/c))-exp(B*d/c));
a2 = -(1i+pi*c/B/d)/(1+(pi*c/B/d)^2);
a3 = 6*d/pi/tau;
a4 = (pi*c/B/d)/(1+(pi*c/B/d)^2)*(1+exp(B*d/c))/(1-exp(-B*tau/c)); %*exp(B*d/c);
h = figure;
t1=0:d/1000:d;
T1 = I0/B.*(a0+a1.*exp(-B.*t1./c)+real(a2.*exp(1i.*pi.*t1./d)));
plot(t1,T1,'LineWidth',2)
set(gca, 'FontSize',14)
hold on

t2 = d:d/1000:tau;
T2 = I0/B.*(a3+a4.*exp(-B.*t2./c));
plot(t2, T2, 'r','LineWidth',2)
xlabel('t(s)','FontSize',18)
ylabel('Temperature of a day(K)','FontSize',18)
hl = legend('t\in[0,d]','t\in[d,\tau]');
set(hl, 'FontSize',14,'box','off')
xlim([0,tau])
print(h,'Temperature_of_a_day.pdf','-dpdf','-r300');

t1(min(T1)==T1)