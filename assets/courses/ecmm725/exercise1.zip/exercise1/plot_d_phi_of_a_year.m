clear;clc;close all;

t = 0:pi/200:2*pi;
y0 = 2;
hd=figure;
y = sin(t-pi/2)+y0;
plot(t,y,'LineWidth',2)
hold on
plot([0,2*pi],[y0,y0],'--')
ylim([0,y0+1.5])
xlim([0,2*pi])

xticks([pi/2 pi 3*pi/2 2*pi])
xticklabels({'0.25','0.5','0.75','1'})
yticks([])
xlabel('t (year)')
ylabel('d')
set(gca,'FontSize',14)
print(hd,'change_of_d_in_a_year.pdf','-dpdf','-r300');

hphi = figure;
phi = -sin(t-pi/2)+y0;
plot(t,phi,'LineWidth',2)

hold on
plot([0,2*pi],[y0,y0],'--')
ylim([0,y0+1.5])
xlim([0,2*pi])

xticks([pi/2 pi 3*pi/2 2*pi])
xticklabels({'0.25','0.5','0.75','1'})
yticks([])
xlabel('t (year)')
ylabel('\phi')
set(gca,'FontSize',14)
print(hphi,'change_of_phi_in_a_year.pdf','-dpdf','-r300');

