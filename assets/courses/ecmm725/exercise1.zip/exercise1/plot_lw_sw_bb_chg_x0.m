clear
clc
close all

alpha = 0.3;
beta = 0.5;
S0 = 400.0;
%x0 = 3.0;
y0 = 6.0;
H = 10^4;

P = (alpha-1)*beta*S0/2.0;
Q = (1-beta)*S0*exp(-y0);

h = figure;
hold on 

for x0=[3.0, 4.0]
    b = P/2;
    c = Q*alpha/2*(1-x0/y0);
    d = -Q/2*(1+x0/y0);
    a = -b*x0-c*exp(-y0)-d*exp(y0);

    z = 0:1:10^5;
    x = x0.*(1-exp(-z/H));
    % 1 is upward, 2 is downward

    S1 = alpha*beta*S0+alpha*(1-beta)*S0*exp(-y0).*exp(-y0/x0.*x);
    S2 = beta*S0+(1-beta)*S0*exp(-y0).*exp(y0/x0.*x);
    Sn = S1-S2;

    dSn = -y0/x0*Q*(alpha.*exp(-y0/x0.*x)+exp(y0/x0.*x));

    L2 = a+b.*x+c.*exp(-y0/x0.*x)+d.*exp(y0/x0.*x);
    L1 = L2-Sn;
    Ln = L1-L2;
    
    B = (L1+L2-dSn)/2;

 
    %plot(z,Sn,'c',z,Ln,'r',z,B,'k','LineWidth',2)

    ylims = ylim;
    plot([H,H],ylims,'--','LineWidth',2)
    if x0==3.0
        h3 = plot(z,[Sn;Ln;B],'LineWidth',2);
    end
    if  x0==4.0
        %plot(z,[Sn;Ln;B],'--','LineWidth',2)
        hb = plot(z,B,'k','LineWidth',2);
    end
end
hl = legend([h3(1),h3(2),h3(3), hb],'Shortwave','Longwave','Blackbody (x_0=3)',...
    'Blackbody (x_0=4)');
set(hl, 'Location','North')
legend('boxoff')

ylabel('Radiation flux (W.m^{-2})')
xlabel('z (km)')
xtk = linspace(0,100,11);
xticks(xtk*10^3)
xticklabels(strtrim(cellstr(num2str(xtk'))'))
view([90,-90])
set(gca,'FontSize',20)
pbaspect([1.4 1 1])
box on
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);
print(h,'lw_sw_blackbody_chg_x0.png','-dpng','-r300');
warning off