% Plot Longwave and shortwave
clear; clc; close all;
alpha = 0.3;
beta = 0.5;
S0 = 400.0;
x0 = 3.0;
y0 = 6.0;
H = 10^4;

P = (alpha-1)*beta*S0/2.0;
Q = (1-beta)*S0*exp(-y0);
b = P/2;
c = Q*alpha/2*(1-x0/y0);
d = -Q/2*(1+x0/y0);
a = -b*x0-c*exp(-y0)-d*exp(y0);

z = 0:1:10^5;
x = x0.*(1-exp(-z/H));
% 1 is upward, 2 is downward

S1 = alpha*beta*S0+alpha*(1-beta)*S0*exp(-y0).*exp(-y0/x0.*x);
S2 = beta*S0+(1-beta)*S0*exp(-y0).*exp(y0/x0.*x);
Sn = S1-S2;

dSn = -y0/x0*Q*(alpha.*exp(-y0/x0.*x)+exp(y0/x0.*x));

L2 = a+b.*x+c.*exp(-y0/x0.*x)+d.*exp(y0/x0.*x);
L1 = L2-Sn;
Ln = L1-L2;

B = (L1+L2-dSn)/2;

h = figure;
plot(z,[Sn;Ln;B],'LineWidth',2)
%plot(z,Sn,'c',z,Ln,'r',z,B,'k','LineWidth',2)
hold on 
ylims = ylim;
plot([H,H],ylims,'--')
hl = legend('Shortwave','Longwave','Blackbody');
set(hl,'Location','north','FontSize',16)
ylabel('Radiation flux (W.m^{-2})')
xlabel('z (km)')
xticks
xtk = linspace(0,100,11);
xticks(xtk*10^3)
xticklabels(strtrim(cellstr(num2str(xtk'))'))
view([90,-90])
set(gca,'FontSize',20)
pbaspect([1.4 1 1])
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);
print(h,'lw_sw_blackbody.pdf','-dpdf','-r300');
