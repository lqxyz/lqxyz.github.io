clear
clc
close all

alpha = 0.3;
beta = 0.5;
S0 = 400.0;
%x0 = 3.0;
y0 = 6.0;
H = 10^4;

P = (alpha-1)*beta*S0/2.0;
Q = (1-beta)*S0*exp(-y0);

h = figure;
hold on 

%for x0=[3.0, 4.0]
for x0=[3.0]
    b = P/2;
    c = Q*alpha/2*(1-x0/y0);
    d = -Q/2*(1+x0/y0);
    a = -b*x0-c*exp(-y0)-d*exp(y0);

    z = 0:1:10^5;
    x = x0.*(1-exp(-z/H));
    % 1 is upward, 2 is downward
    V1 = alpha*beta*S0.*ones(size(x));
    U1 = alpha*(1-beta)*S0*exp(-y0).*exp(-y0/x0.*x);
    S1 = V1 + U1;
    V2 = beta*S0.*ones(size(x));
    U2 = (1-beta)*S0*exp(-y0).*exp(y0/x0.*x);
    S2 = V2+U2;
    Sn = S1-S2;

    dSn = -y0/x0*Q*(alpha.*exp(-y0/x0.*x)+exp(y0/x0.*x));

    L2 = a+b.*x+c.*exp(-y0/x0.*x)+d.*exp(y0/x0.*x);
    L1 = L2-Sn;
    Ln = L1-L2;
    
    B = (L1+L2-dSn)/2;

    %plot(z,Sn,'c',z,Ln,'r',z,B,'k','LineWidth',2)

    if x0==3.0
        %h3 = plot(z,[L1;L2;S1;S2;B],'LineWidth',2);
        h7 = plot(z,[L1;L2;V1;V2;U1;U2;B],'LineWidth',2);
    end
    ylims = ylim;
    plot([H,H],ylims,'k--','LineWidth',1)
%     if  x0==4.0
%         %plot(z,[Sn;Ln;B],'--','LineWidth',2)
%         hb = plot(z,B,'k','LineWidth',2);
%     end
end
% hl = legend([h3(1),h3(2),h3(3),h3(4),h3(5),hb],'Longwave \uparrow',...
% 'Longwave \downarrow','Shortwave \uparrow','Shortwave \downarrow',...
% 'Blackbody (x_0=3)','Blackbody (x_0=4)');
%  hl = legend([h7(1),h7(2),h7(3),h7(4),h7(5),h7(6),h7(7),hb],'L \uparrow',...
%  'L \downarrow','V \uparrow','V \downarrow', 'U \uparrow','U \downarrow',...
%  'B (x_0=3)','B (x_0=4)');
 hl = legend([h7(1),h7(2),h7(3),h7(4),h7(5),h7(6),h7(7)],'L \uparrow',...
 'L \downarrow','V \uparrow','V \downarrow', 'U \uparrow','U \downarrow',...
 'B (x_0=3)');
rect = [0.5, 0.6, .25, .25];
set(hl, 'Position', rect)
%set(hl, 'Location','Best')
legend('boxoff')

ylabel('Radiation flux (W.m^{-2})')
xlabel('z (km)')
xtk = linspace(0,100,11);
%xticks(xtk*10^3)
%xticklabels(strtrim(cellstr(num2str(xtk'))'))
set(gca, 'XTick',xtk*10^3,'XTickLabel',strtrim(cellstr(num2str(xtk'))'))
%hold on,
%arrow()
view([90,-90])
set(gca,'FontSize',20)
pbaspect([1 2 1])
box on
colors = get(h7,'color');

xs = 0.285;
ys = 0.6;
% plot arrow to indicate the small figure
ar = annotation('arrow',[0.13,xs],[0.12,ys*0.95],'LineStyle','--');
% ar.X = [0,0];
% ar.Y = [0.28,0.5];
% create a new pair of axes inside current figure
axes('position',[xs ys .2 .2])
box on % put box around new pair of axes
indexOfInterest = (z < 1000); % range of t near perturbation
ha1 = plot(z(indexOfInterest), U1(indexOfInterest),'color', colors{5}, 'LineWidth',2);
hold on
ha2 = plot(z(indexOfInterest), U2(indexOfInterest),'color', colors{6}, 'LineWidth',2); % plot on new axes
%hsub = plot(z(indexOfInterest),[U1(indexOfInterest);U2(indexOfInterest)], 'color',colorOrder(1,:),'LineWidth',2);
hal = legend([ha1,ha2],'U \uparrow','U \downarrow');
set(hal, 'Location','north')
legend('boxoff')

% plot on new axes
view([90,-90])
ylabel('Radiation flux (W.m^{-2})')
%xlabel('z (m)')
xlabel('z (km)')
xtk2 = linspace(0,1,3);
%xticks(xtk*10^3)
%xticklabels(strtrim(cellstr(num2str(xtk'))'))
set(gca, 'XTick',xtk2*10^3,'XTickLabel',strtrim(cellstr(num2str(xtk2'))'))
set(gca,'FontSize',13)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);
print(h,'lwud_uvud_blackbody_chg_x0_3_0.png','-dpng','-r300');
