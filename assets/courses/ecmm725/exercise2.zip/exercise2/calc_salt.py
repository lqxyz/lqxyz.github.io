import numpy as np
G = np.pi
g = 9.8
U = 0.05
H = 0.2
r = 1-1.0/( np.exp( G**2 * U**2 /g /H) )
print r
r = np.exp( G**2 * U**2 /g /H)-1 
print r
rho_b = 1000*np.exp( G**2 * U**2 /g /H)
print rho_b

