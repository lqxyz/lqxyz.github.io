% Plot the figure between phase velocity (cp), group velocity (cg)
% and wavelength

g = 9.8;
sigma = 10^5/10^3;
lambda = 1:0.1:10^3/2;

cp = sqrt(g.*lambda/2./pi+2*pi*sigma./lambda);
cg = cp/2.0+2*pi*sigma./lambda./cp;
hold on
h1 = plot(lambda, cp,'k','LineWidth',2);
h2 = plot(lambda, cg,'k:','LineWidth',2);

set(gca,'FontSize',15)
xlabel('Wavelength')
ylabel('Phase and group velocity ')
legend([h1,h2],'Phase velocity', 'Group velocity','Location','Best')
box on