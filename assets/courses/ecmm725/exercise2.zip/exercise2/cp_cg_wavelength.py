# Plot the figure between phase velocity (cp), group velocity (cg) and wavelength

import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import os
matplotlib.rcParams['font.sans-serif'] = "Arial"
matplotlib.rcParams['font.family'] = "sans-serif"

g = 9.8
sigma = 0.01/10**3
wl = np.linspace(0.001, 0.1, 1000)

cp = np.sqrt(g*wl/2.0/np.pi + 2*np.pi*sigma/wl)
cg = cp/2.0+2*np.pi*sigma/wl/cp

fig, ax = plt.subplots(1,1)
ax.plot(wl, cp, 'k-', linewidth=2, label='phase velocity');
ax.plot(wl, cg, 'k:', linewidth=2, label='group velocity');

ax.set_xlabel('Wavelength (m)', fontsize=15)
ax.set_ylabel('Phase and group velocity (m/s)', fontsize=15)
ax.tick_params(labelsize=13)

legend = ax.legend(loc='best', shadow=False, fontsize='x-large')

figname = 'group_phase_velocity.pdf'
#plt.title('', fontsize=20)
fig.savefig(figname, bbox_inches='tight', pad_inches=0.01)
os.system('display '+figname)
