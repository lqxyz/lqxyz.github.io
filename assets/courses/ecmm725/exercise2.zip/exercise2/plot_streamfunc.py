import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import os
matplotlib.rcParams['font.sans-serif'] = "Arial"
matplotlib.rcParams['font.family'] = "sans-serif"

x = np.linspace(0, 30000, 100)
y = np.linspace(0, 1000, 100)
X, Y = np.meshgrid(x, y)
U = 1
A = 1 
s = 0.001
f0 = 10**(-4)
Z = Y *(U + A*np.exp(-np.sqrt(s*f0/U) * X) ) 

fig, ax = plt.subplots(1,1)
ax.axhline(linewidth=1.7, color="k")
ax.axvline(linewidth=1.7, color="k")

cp = ax.contour(X, Y, Z,  colors='black') #, levels=levels)

fmt = {}
for lev in cp.levels:
    fmt[lev] = '%.0f'%lev
# Label every other level using strings
ax.clabel(cp, cp.levels[::1], inline=True, fmt=fmt, fontsize=12)
#ax.clabel(cp, inline=True, fontsize=10)

'''
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))

plt.yticks([0, 1, 2, 3, 4], ['', r'$1$', r'$2$', r'$3$', ''], fontsize=20)
plt.xticks([0, 1, 2, 3, 4, 5], [r'$0$', r'$1$', r'$2$', r'$3$', r'$4$', ''], fontsize=20)
plt.arrow(4.9, -0.003, 0.1, 0, width=0.01, color="k", clip_on=False, head_width=0.1, head_length=0.1)
plt.arrow(0.003, 3.9, 0, 0.1, width=0.01, color="k", clip_on=False, head_width=0.1, head_length=0.1)
'''
ax.set_xlabel('$x$', fontsize=22)
ax.set_ylabel('$y$', fontsize=22)

figname = 'U_streamline_contour.pdf'
plt.title('Stream function: $\psi(x,y)=y\phi(x)$', fontsize=20)
fig.savefig(figname, bbox_inches='tight', pad_inches=0.01)
os.system('open '+figname)
