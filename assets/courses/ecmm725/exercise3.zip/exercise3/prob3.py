import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import matplotlib.patches as patches

import os
matplotlib.rcParams['font.sans-serif'] = "Arial"
matplotlib.rcParams['font.family'] = "sans-serif"

Omega = 2*np.pi/24./60/60
a = 6374*1e3
beta = 2*Omega/a*np.cos(np.deg2rad(35))
#print beta
#print np.pi*0.1/1.87/3/1e-2
#print np.pi/3/1e6
#print np.pi*0.1/1.87/3/1e-2/1e5*5000*1e3
#print np.pi*0.1/1.87/3/1e-2/500
#print np.pi*0.1/1.87/3/1e-2/1e5*5000*1e3/500
f0=2*Omega*np.sin(np.deg2rad(35))
Ly=3e6
#y=np.linspace(0,Ly,1000)
y=np.linspace(-Ly/2,Ly/2,1000)
f = f0+beta*y
'''
plt.plot(y,f)
plt.plot([0,3e6],[f0,f0])
plt.plot([0,3e6],[2*Omega,2*Omega])
plt.show()
'''
h = 500
print 'beta'+str(beta) 
print np.pi*0.1/1.87/3/1e-2/h
v = np.pi*0.1/1.87/3/1e-2/h*np.sin(np.pi*y/3e6)
Wz = beta*v/f
#plt.plot(y,f)
#plt.plot(y,v)
print max(f), min(f)

fig, ax = plt.subplots(1,1)
#ax.plot(y,v, label='v')
ax.plot(y,Wz, label='w_z')
ax.plot([-Ly/2,Ly/2],[0,0],'--')
xticks = np.linspace(-Ly/2,Ly/2,7)
ax.set_xticks(xticks)
ax.set_xticklabels([str(int(tick/1e3)) for tick in xticks], fontsize=16)
plt.yticks(fontsize=16)
ax.set_xlim(-Ly/2,Ly/2)
ax.set_xlabel('$L_y(km)$', fontname="Arial", fontsize=20)
ax.set_ylabel('$w_z (m/s)$', fontname="Arial", fontsize=20)
ax.add_patch( patches.Arrow( -Ly/2*0.6, -0.5e-9, 0, -1e-9, width=Ly/10, fill=False ))
ax.add_patch( patches.Arrow( Ly/2*0.6, 0.1e-9, 0, 1e-9, width=Ly/10, fill=False ))

figname = 'eckman.pdf'
fig.savefig(figname, bbox_inches='tight', pad_inches=0.01)
os.system('open '+figname)
