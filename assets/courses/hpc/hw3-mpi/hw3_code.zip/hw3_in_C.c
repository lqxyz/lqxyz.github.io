/************* HPC homework 3 *************
* Author:   Qun Liu
* Time  :   2015-3-22
* *****************************************/
#include<mpi.h>
#include<stdio.h>
#include<string.h>

void printInfo();
int dataTransfer();
int sayHello();

int main( int argc, char** argv)
{
    MPI_Init(&argc, &argv);
    printInfo();
    MPI_Barrier(MPI_COMM_WORLD);
    dataTransfer();
    MPI_Barrier(MPI_COMM_WORLD);
    sayHello();
    MPI_Finalize();
   return 0;
} 

/***************** Print Function ****************/
void printInfo()
{
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("Process ID is %4d, the total number of processes is %4d.\n", rank, size);
}

/***************** Data Transfer Function ****************/
int dataTransfer()
{
    int rank, size, senddata, recvdata, tag=1;
    MPI_Status status;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if(size<2) // if the numer of processes is less than 2
    { 
        printf("Error: Num of processes >= 2, please try again.\n");
        return -1;
    }
    
    if(rank==0)          // The first one only sends data
    {
        printf("\nPlease input a data(integer) to transfer:\n");
        scanf("%d", &senddata);
        MPI_Send(&senddata, 1, MPI_INT, rank+1, tag, MPI_COMM_WORLD);
        printf("Process %4d sends    data(%d) to   process %4d.\n", rank, senddata, rank+1);
    }    
    else if(rank>0 && rank<size-1) // The ones between rank 1 and rank size-2 both send and receive data
    {
        MPI_Recv(&recvdata, 1, MPI_INT, rank-1, tag, MPI_COMM_WORLD, &status);
        printf("Process %4d receives data(%d) from process %4d.\n", rank, recvdata, rank-1);
        MPI_Send(&recvdata, 1, MPI_INT, rank+1, tag, MPI_COMM_WORLD);
        printf("Process %4d sends    data(%d) to   process %4d.\n", rank, recvdata, rank+1);
    }
    else                 // The last one only receives data        
    {
        MPI_Recv(&recvdata, 1, MPI_INT, rank-1, tag, MPI_COMM_WORLD, &status);
        printf("Process %4d receives data(%d) from process %4d.\n", rank, recvdata, rank-1);
    }
    return 0;
}


/***************** Say Hello Function ****************/
int sayHello()
{
    int i, rank, size, tag=2;
    char sendhello[10], recvhello[10];
    MPI_Status status;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if(size<2) // if the numer of processes is less than 2
    { 
        printf("Error: Num of processes >= 2, please try again.\n");
        return -1;
    }

    strcpy(sendhello,"hello");
    for(i=0; i<size; i++)
        if(i != rank)
        {
            MPI_Send(sendhello, strlen(sendhello)+1, MPI_CHAR, i, tag, MPI_COMM_WORLD);
            printf("Process %4d sends    message \"%s\" to   process %4d.\n", rank, sendhello, i);
            MPI_Recv(recvhello, 10, MPI_CHAR, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);
            printf("Process %4d receives message \"%s\" from process %4d.\n", rank, recvhello, status.MPI_SOURCE);
        }

    return 0;
}

