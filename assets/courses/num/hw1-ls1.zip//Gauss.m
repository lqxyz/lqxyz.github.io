function x = Gauss(A, b)

n = length(b);
%[L, U, P] = lu(A);
[LU, p] = lu_pivot_in_col(A);
b = b(p);
% Ly = P*b
y = zeros(n, 1);
y(1) = b(1);
for i = 2:n
    y(i) = b(i) - LU(i, 1:i-1) * y(1:i-1);
end
% Ux = y
x = zeros(n, 1);
x(n) = y(n) / LU(n, n);
for i = n-1:-1:1
    x(i) = (y(i) - LU(i, i+1:n)* x(i+1:n)) / LU(i, i);
end
end