clear;
clc;
% Excels possible range cells
range = {'A','B','C','D','E','F','G','H','I', 'J','K','L','M','N','O','P',...
          'Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD'};
file_gauss = 'Results_Gauss.xlsx';
file_chol = 'Results_Chol.xlsx';
file_r_gauss = 'Results_r_Gauss.xlsx';
file_r_chol = 'Results_r_Chol.xlsx';
file_dx_gauss = 'Results_delta_x_Gauss.xlsx';
file_dx_chol ='Results_delta_x_Chol.xlsx';
for n = 2:15
    H = hilb(n);
    x = ones(n, 1);
    b = H * x;

    % solve H*y_gauss = b
    %y_gauss = H \ b;
    y_gauss = Gauss(H, b);
    % solve H*y_Chol = b
    y_chol = Cholesky(H, b);
    % ????
    r_gauss = b - H*y_gauss;
    r_chol = b - H*y_chol;
    % ????
    delta_x_gauss = y_gauss - x;
    delta_x_chol = y_chol - x;
    % Write results to Excels
    xlswrite(file_gauss,y_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_gauss,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_chol,y_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_chol,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);

    xlswrite(file_r_gauss, r_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_r_gauss,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_r_chol, r_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_r_chol,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);

    xlswrite(file_dx_gauss, delta_x_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_dx_gauss,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_dx_chol, delta_x_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_dx_chol,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    % ?????cond(H)2
    condH(n-1) = cond(H, 2);
end

file_gauss_regu = 'Results_Gauss_regu.xlsx';
file_chol_regu = 'Results_Chol_regu.xlsx';
file_r_gauss_regu = 'Results_r_Gauss_regu.xlsx';
file_r_chol_regu = 'Results_r_Chol_regu.xlsx';
file_dx_gauss_regu = 'Results_delta_x_Gauss_regu.xlsx';
file_dx_chol_regu ='Results_delta_x_Chol_regu.xlsx';


% Tikhonov Regularization
alpha = 1e-4;
for n = 2:15
    H = hilb(n);
    x = ones(n, 1);
    b = H'* H * x;
    A = H' * H + alpha * diag(ones(n, 1));
    % Solve A*y_gauss = b
    y_gauss = Gauss(A, b);
    % Solve A*y_chol = b
    y_chol = Cholesky(A, b);
    r_gauss = H*x - H*y_gauss;
    r_chol = H*x - H*y_chol;
    delta_x_gauss = y_gauss - x;
    delta_x_chol = y_chol - x;

    % Write results to Excels
    xlswrite(file_gauss_regu, y_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_gauss_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_chol_regu, y_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_gauss_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);

    xlswrite(file_r_gauss_regu, r_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_r_gauss_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_r_chol_regu, r_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_r_chol_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);

    xlswrite(file_dx_gauss_regu, delta_x_gauss, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_dx_gauss_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_dx_chol_regu, delta_x_chol, [range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_dx_chol_regu,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);

end