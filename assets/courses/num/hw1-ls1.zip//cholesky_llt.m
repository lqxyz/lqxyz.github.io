function L = cholesky_llt(A)

n = length(A);
L = zeros(n);
L(1,1) = A(1,1)^0.5;
L(2:n, 1) = A(1,2:n)/L(1,1);
for j = 2:n-1
    L(j,j) = (A(j,j) - sum(L(j,1:j-1).^2))^0.5;
    for i = j+1:n
        L(i,j) = (A(i,j)- L(i, 1:j-1)*L(j, 1:j-1)') / L(j,j);
    end
end
L(n,n) = (A(n,n) - sum(L(n,1:n-1).^2))^0.5;