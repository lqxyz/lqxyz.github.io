function [LU, p] = lu_pivot_in_col(A)

[m, n] = size(A);
% Check if A a square matrix.
if m ~= n
    disp('A must be a square matrix, please check again.')
    return
end

% LU composition and permutation
p = 1:n;
LU = A;
for j = 1:n
    [Max, index] = max(abs(LU(j:n, j)));
    if Max == 0
        disp('The matrix is singular.')
        return
    end
    index = index + j - 1;
    if index ~= j
        tmp = p(j);
        p(j) = p(index);
        p(index) = tmp;

        % Exchange the two rows of the matrix
        tmp = LU(j,:);
        LU(j, :) = LU(index, :);
        LU(index,:) = tmp;
    end
    if j == n
        break;
    end

    LU(j+1:n, j) = LU(j+1:n, j) / LU(j, j);
    for k = j+1:n
        LU(k, j+1:n) = LU(k, j+1:n) - LU(k, j) * LU(j,j+1:n);
    end
    %LU(j+1:n, j+1:n) = LU(j+1:n, j+1:n) - LU(j+1:n, j) * LU(j,j+1:n);
end