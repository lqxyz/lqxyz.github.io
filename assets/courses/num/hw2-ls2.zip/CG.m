function x = CG(A, b)
% x = CG(A, b)
% Calculate Ax=b using Conjugate Gradient method
% Author: LIU Qun
% Email: liu-q14@mails.tsinghua.edu.cn
% Time: 2014-10-25

n=length(b);
x=zeros(n, 1);
rk=b-A*x;
p=rk;
while(max(abs(rk))>1e-8)
    alpha = (rk' * rk)/(p' * A*p);
    x = x + alpha * p;
    rk1 = rk - alpha*A*p;
    beta = (rk1'*rk1)/(rk'*rk);
    p = rk1 + beta * p;
    rk = rk1;
end 



