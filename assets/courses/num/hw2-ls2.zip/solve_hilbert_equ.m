clear;
clc;

% 定义要写入位置
range = {'A','B','C','D','E','F','G','H','I', 'J','K','L','M','N','O'};
% 定义松弛因子w
w=1.05;

% 定义写入文件的名称
file_sor='sor_x.xlsx';
file_sor_err='sor_delta_x.xlsx';
file_sor_r='sor_r.xlsx';
file_sor_norm_dx='sor_norm_dx.xlsx';

file_CG='CG_x.xlsx';
file_CG_err='CG_delta_x.xlsx';
file_CG_r='CG_r.xlsx';
file_CG_norm_dx='CG_norm_dx.xlsx';
N=15;
norm_delta_x_sor = zeros(1,N-1);
norm_delta_x_CG = zeros(1,N-1);
for n=2:N
    A=hilb(n);
    x=ones(n,1);
    b=A*x;
    %%---------------------- SOR Method ----------------------%%
    y_sor=sor(A, b, w);
    delta_x_sor=y_sor-x;    % 解的误差
    r_sor=b-A*y_sor;        % 残差向量
    % 计算误差的向量范数(二范数)
    norm_delta_x_sor(n-1) = norm(delta_x_sor);
    % 写入x
    xlswrite(file_sor,y_sor,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_sor,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    % 写入x的误差
    xlswrite(file_sor_err,delta_x_sor,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_sor_err,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    % 写入残差
    xlswrite(file_sor_r,r_sor,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_sor_r,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_sor_norm_dx,{['n=' num2str(n)]},[range{n-1},'1:', range{n-1}, '1'])
    %%---------------------- CG Method ----------------------%%
    y_CG=CG(A, b);
    delta_x_CG=y_CG-x;    % 解的误差
    r_CG=b-A*y_CG;        % 残差向量
    % 计算误差的向量范数(二范数)
    norm_delta_x_CG(n-1) = norm(delta_x_CG);
    % 写入x
    xlswrite(file_CG,y_CG,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_CG,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    % 写入x的误差
    xlswrite(file_CG_err,delta_x_CG,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_CG_err,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    % 写入残差
    xlswrite(file_CG_r,r_CG,[range{n-1},'2:', range{n-1}, num2str(n+1)])
    xlswrite(file_CG_r,{['n=' num2str(n)]}, [range{n-1} '1:' range{n-1} '1']);
    xlswrite(file_CG_norm_dx,{['n=' num2str(n)]},[range{n-1},'1:', range{n-1}, '1'])
end

xlswrite(file_sor_norm_dx,norm_delta_x_sor,[range{1},'2:', range{N-1}, '2'])
xlswrite(file_CG_norm_dx,norm_delta_x_CG,[range{1},'2:', range{N-1}, '2'])

