function x=sor(A, b, w)
% x=sort(A, b, w)
% 超松弛迭代法
% x: return value, the solution to Ax=b
% w should between (0, 2)
% Author: LIU Qun
% Time: 2014-10-24

n=length(b);
x=zeros(n, 1);
err=1;
while(err>1e-8)
    x_init=x;
    for i=1:n
        x(i)=(1-w)*x_init(i)+w/A(i,i)*(b(i)-A(i,1:i-1)*x(1:i-1)-A(i,i+1:n)*x(i+1:n));
    end
    err=max(abs(x-x_init));
end

