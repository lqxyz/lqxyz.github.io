% 閲囩敤绗竴绉嶈凯浠ｆ柟娉曠殑Steffensen鍔犻€熸硶杩涜杩唬
% Author: Qun LIU
% Email: liu-q14@mails.tsinghua.edu.cn
% Time: 2014-11-02

clear;
clc;
% 鍒濆€