% 閲囩敤绗簩绉嶈凯浠ｆ硶鐨凷teffensen鍔犻€熸硶
% Author: Qun LIU
% Email: liu-q14@mails.tsinghua.edu.cn
% Time: 2014-11-02

clear;
clc;
%鍒濆€