% 閲囩敤Newton杩唬鏂规硶杩涜杩唬
% Author: Qun LIU
% Email: liu-q14@mails.tsinghua.edu.cn
% Time: 2014-11-02

clear;
clc;
% 鍒濆€