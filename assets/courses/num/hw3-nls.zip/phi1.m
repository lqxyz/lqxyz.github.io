function y = phi1(x)
% (1)鐨勮凯浠ｅ嚱鏁