% Three order convergence
% x = x - f(x)/f'(x) - f"(x)f(x)/(2f'(x)^3)
% Author: Qun LIU
% Email: liu-q14@mails.tsinghua.edu.cn

clear;
clc;
% 鍒濆€