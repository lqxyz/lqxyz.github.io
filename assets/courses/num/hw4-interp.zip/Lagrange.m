function f=Lagrange(n, x)
% Lagrange鎻掑€煎嚱鏁