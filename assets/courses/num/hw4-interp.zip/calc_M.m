function M = calc_M(xn, fn, h)


% 鑺傜偣涓暟
n = length(xn);
% 瀹氫箟杩斿洖鍊