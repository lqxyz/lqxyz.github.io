% Homework for interpolation
% Author: Qun Liu
% Time: 2014-11-25

clear;
clc;
close all;

x = -1:0.01:1;
%% Lagrange鎻掑€