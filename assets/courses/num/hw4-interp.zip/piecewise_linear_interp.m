function f=piecewise_linear_interp(n, x)
% function f=piecewise_linear_interp(n, x)
% n:    the number of interpolation nodes
% x:    the vector contains the x of the point you want to calculate f(x)
% f:    the return value
% Qun Liu 2014-11-26


% 鎻掑€艰妭鐐