function fS=spline_interp(n, x)
% n 鏄彃鍊艰妭鐐圭殑涓暟
% x 瑕佽绠楃殑鐐圭殑妯潗鏍