function f=Lagrange(n, xn, x)
% Lagrange插值函数, n为插值节点的个数, x为要求的函数点的值
% Qun Liu 2014-12-13

f = zeros(size(x));
for i = 1:n+1
    li = 1;
    for j = 1:n+1
        if i~=j
            %li = li * (x(k)-xn(j))/(xn(i)-xn(j));
            li = li .* (x-xn(j))/(xn(i)-xn(j));
         end
     end
    %f(k)= f(k)+li*1/(1+25*xn(i)^2);   
    f = f+ li*xn(i)^2*log(xn(i)+2); 
end    
