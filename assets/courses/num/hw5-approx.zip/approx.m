% 计算f(x)=x^2*ln(2+x)的最佳平方逼近三次多项式,权函数rho(x)=1
% Author: Qun Liu  
% Time: 2014-12-11
clear;
clc;
close all;
% 定义多项式的阶数为3(n=4).
n = 3;
N = n+1;
% 函数的x坐标值
xx = -1:0.01:1;
% 函数f(x)的值
f = xx.^2 .* log(2+xx);
%% 计算权函数为rho(x)=1的最佳平方逼近三次多项式
b = zeros(N,1);
A = zeros(N, N);
% 定义符号变量, 用于求定积分
syms x
% 定义符号函数, 要逼近的的函数f
F = x^2*log(2+x);
for i = 1:N
    for j = i:N
        A(i,j) = int(x^(i-1)*x^(j-1), -1, 1);
        if i~=j
        	A(j,i) = A(i,j);
        end
    end
    b(i) = int(F*x^(i-1), -1, 1);
end
% 最佳平方逼近三次多项式的系数
a = A\b;

%% 最佳平方逼近三次多项式 
y1=0;
for i = 1:N
    y1 = y1 + a(i).* xx.^(i-1);
end
figure, 
set(gcf,'outerposition',get(0,'screensize'));
subplot(2,2,1),
plot(xx,f,'-',xx,y1,'r-', 'linewidth', 2);
%plot(xx, [f;y1], 'linewidth', 2);
h = legend('$f(x)=x^2ln(2+x)$','$p_3(x)$');%Cubic\ polynomial\ of\ best\ square\ approximation\
%h = legend('$f(x)=x^2ln(2+x)$','Cubic\ polynomial\ of\ best\ square\ approximation\ $p_3(x)$');
set(h, 'Interpreter','Latex','FontSize',14,'FontWeight','bold','Box','off','Location','Best')
%title('原函数与最佳平方逼近三次多项式的比较','FontSize',14,'FontWeight','bold');
hx = xlabel('$x$');
hy = ylabel('$y$');
set([hx,hy], 'Interpreter','Latex','FontSize',14,'FontWeight','bold')
%% Chebyshev 截断级数
syms x
T0 = sym('1');
T1 = x;
% a 是广义傅里叶级数的系数
a2 = zeros(N, 1);
% rho为权函数
rho = 1/sqrt(1-x^2);
%a2(1) = int(rho*F*T0,-1,1)/pi;
a2(1) = quad(eval(['@(x)',vectorize(rho*F*T0)]),-1,1)/pi;
a2(2) = quad(eval(['@(x)',vectorize(rho*F*T1)]),-1,1)/(pi/2);
% y2是函数返回值 
y2 = 0;
y2 = y2 + a2(1)*1 + a2(2)*xx;
for i = 3:N
    T2 = 2*x*T1-T0;
    T = eval(['@(x)',vectorize(T2)]);
    a2(i) =quad(eval(['@(x)',vectorize(rho*F*T2)]),-1,1)/(pi/2);
    %y2 = y(2) + a(i)*subs(T2, xx);
    T0 = T1;
    T1 = T2;
    y2 = y2 + a2(i)*T(xx);
end
subplot(2,2,2)
plot(xx,f,'-',xx,y2,'r-', 'linewidth', 2);
%plot(xx, [f;y1], 'linewidth', 2);
h = legend('$f(x)=x^2ln(2+x)$','Chebyshev $S_3^*$');
set(h, 'Interpreter','Latex','FontSize',14,'FontWeight','bold','Box','off','Location','Best')
%title('原函数与Chebyshev截断级数(n=3)的比较','FontSize',14,'FontWeight','bold');
hx = xlabel('$x$');
hy = ylabel('$y$');
set([hx,hy], 'Interpreter','Latex','FontSize',14,'FontWeight','bold')
%% 插值余项极小化法
k = 0:n;
xn = cos((2*k+1)./(2*N).*pi);
y3 = Lagrange(n, xn, xx);
subplot(2,2,3),
plot(xx,f,xx,y3, 'linewidth', 2);
%plot(xx, [f;y1], 'linewidth', 2);
h = legend('$f(x)=x^2ln(2+x)$','$\tilde{L}_3(x)$');
set(h, 'Interpreter','Latex','FontSize',14,'FontWeight','bold','Box','off','Location','Best')
%title('原函数与插值余项极小化法(n=3)的比较','FontSize',14,'FontWeight','bold');
hx = xlabel('$x$');
hy = ylabel('$y$');
set([hx,hy], 'Interpreter','Latex','FontSize',14,'FontWeight','bold')
%% 绘制三种方法对比的图像
subplot(2,2,4)
plot(xx,f,'-',xx,y1,':',xx,y2,'-.',xx,y3, 'linewidth', 2);
%plot(xx, [f;y1], 'linewidth', 2);
h = legend('$f(x)=x^2ln(2+x)$','$p_3(x)$', 'Chebyshev $S_3^*$','$\tilde{L}_3(x)$');
%Cubic\ polynomial\ of\ best\ square\ approximation\ 
set(h, 'Interpreter','Latex','FontSize',14,'FontWeight','bold','Box','off','Location','Best')
hx = xlabel('$x$');
hy = ylabel('$y$');
set([hx,hy], 'Interpreter','Latex','FontSize',14,'FontWeight','bold')
set(gcf, 'PaperPositionMode', 'auto')   % Use screen size
% 打印图片
print -djpeg  -r300  approx.jpeg;

%% 误差
% 绝对误差
figure,
set(gcf,'outerposition',get(0,'screensize'));
plot(xx, abs([f-y1;f-y2;f-y3]),'LineWidth',2)
h = legend('$|f(x)-P_3(x)|$', '$|f(x)-S_3^*(x)|$','$|f(x)-\tilde{L}_3(x)|$');
set(h, 'Interpreter','Latex','FontSize',14,'FontWeight','bold','Box','off','Location','Best')
title('The absolute error between different methods','FontSize',14,'FontWeight','bold');
hx = xlabel('$x$');
hy = ylabel('$y$');
set([hx,hy], 'Interpreter','Latex','FontSize',14,'FontWeight','bold')
set(gcf, 'PaperPositionMode', 'auto')   % Use screen size
% 打印图片
print -djpeg  -r300  approxabserror.jpeg;
