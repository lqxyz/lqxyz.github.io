function sum = CompoundGLfive(a, b, n, f)
% Gauss-Legendre Quadrature
% 采用五点Gauss-Legendre求积公式
% 其中, a, b为区间[a, b]的端点值, n为复合求积中要分的段数, f为要求积分的函数
% Qun Liu 2014-12-24

h = (b-a)/n;
aa = a : h : b-h;
bb = a+h : h : b;
% 积分的累积结果
sum = 0;
syms t
for i = 1 : n
    x2t = 0.5*( aa(i)+bb(i) ) + 0.5*( bb(i)-aa(i) )*t;
    f = subs(f, 'x', x2t);
    f = eval(['@(t)',vectorize(f)]);
    sum = sum + (bb(i)-aa(i))/2*(0.5*(bb(i)-aa(i)) * ( f(0.9061798459)*0.2369268851...
        + f(-0.9061798459)*0.2369268851 + f(0.5384693101)*0.4786286705...
        + f(-0.5384693101)*0.4786286705+ f(0)*0.5688888889 ));
end
