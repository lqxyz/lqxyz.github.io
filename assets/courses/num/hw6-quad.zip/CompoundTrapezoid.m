function r=CompoundTrapezoid(f,a,b,n)
% Computing Compound Trapezoid Integration);
% f is a string containing x, denote a function
% Example: 'x/(4+x^2)'
% a,b are the start and end point of the interval
% n is the number of small segments of interval
% Qun Liu 2014-12-20

f=eval(['@(x)',vectorize(f)]);
h = (b-a)/n;
r = h/2*(f(a)+2*sum(f(a+h:h:b-h))+f(b));