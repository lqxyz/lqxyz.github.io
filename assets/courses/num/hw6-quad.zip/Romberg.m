function [f, T] = Romberg(a, b, epsilon, f)
% 计算函数f的Romberg积分
% a, b 为区间端点值,epsilon为控制误差, f为关于x的函数, 字符串形式
% f 为计算的积分的结果, T 为计算过程中所有的中间结果
% Qun Liu 2014-12-24
L=1; % 区间[a,b]要分割的份数
T(1,1)=CompoundTrapezoid(f,a,b,L);
T(2,1)=CompoundTrapezoid(f,a,b,L+1);
T(1,2) = (4*T(2,1) - T(1,1)) / (4-1);
while(abs(T(1,L)-T(1,L+1)) > epsilon)
    L = L+1;
    T(L+1,1) = CompoundTrapezoid(f,a,b,2^L);
    for j=1:L
        k= L-j+1;
        T(k, j+1) =  (4^j*T(k+1, j) - T(k, j)) / (4^j-1);
    end 
end
f = T(1, L+1);
for j=2:L+1
    T(j:L+1, j)=T(1:L+2-j, j);
    T(1:j-1,j)=0;
end