% 数值积分和数值微分上机实验
% Qun Liu 2014-12-24
clear;
clc;
% 定义要计算的函数f
f='1/x^2*sin(2*pi/x)';
% 定义区间[a,b]
a = 1;
b = 3;

% 求五点Gauss-Legendre复合求积,分成4个子区间
n = 4;
fGL = CompoundGLfive(a, b, n, f);
% Romberg积分
% 定义误差
epsilon = 1e-7;
[fR, T] = Romberg(a, b, epsilon, f);
% 定义真值y
y=-0.238732414637843;
% 计算绝对误差和相对误差
fGL_abs = abs(fGL-y);
fGL_rel = fGL_abs /abs(y);
fR_abs = abs(fR-y);
fR_rel = fR_abs /abs(y);
disp(['五点Gauss-Legendre复合求积(分成' num2str(n) '段)的值为:' num2str(fGL,15) ', 绝对误差为' num2str(fGL_abs,15) ', 相对误差为' num2str(fGL_rel,15)])
disp(['Romberg积分的值为:' num2str(fR,15) ', 绝对误差为' num2str(fR_abs,15) ', 相对误差为' num2str(fR_rel,15)])